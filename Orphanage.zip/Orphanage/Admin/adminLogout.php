<?php
	 setcookie('isaac', '$a', time()-3600);
   header("location: adminLogin.php");
?>