<?php
include"../includes/dbconn.php";
//connect to the database
$db = mysqli_connect(servername, username, password, dbname);
$errors = array();

//Admin Index Start
if(isset($_COOKIE["isaac"])) $username_id= $_COOKIE["isaac"]; else header("location:adminLogin.php");
//Select Query to show data from database table
$sql1 = "SELECT * FROM category order by id desc";
$result = mysqli_query($db, $sql1);
$count = 0;  //Count the number of rows in that particular table
if(mysqli_num_rows($result)>$count){//return no of rows in present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result)) //feteches a result row as an assoc array
{
$id[] = $row["id"];
$category[] = $row["category"];
$count++;
}
}

//if user clicked on the submit button receive the value from the form
if(isset($_POST['submit'])){
	$d = $_FILES['sub_image']['name'];
	$e = 'upload/' .$d;
	$f = move_uploaded_file($_FILES['sub_image']['tmp_name'],$e);
	$g = mysqli_real_escape_string($db, $_POST['title']); //mysqli() help to protect ur database fr SQL injection, and escape 
	$h = mysqli_real_escape_string($db, $_POST['story']);	//character
	$i = mysqli_real_escape_string($db, $_POST['raised']);
	$trn_date = date("Y-m-d H:i:S");
	$k = mysqli_real_escape_string($db, $_POST['cat_id']);
	
	//Query database or execute SQL query to insert into database
	$insert = mysqli_query($db, "insert into about(sub_image, title, story, raised, trn_date, cat_id)values('$d', '$g', '$h', '$i', '$trn_date' '$k', now())") or die('could not insert' .mysqli_error($db));
	if($insert){
		array_push($errors, "Content Uploaded Successfully");
	}
	else{
		array_push($errors, "Not Uploaded");
	}
}
//Admin Index End

//Admin Blog Start
if(isset($_COOKIE["isaac"])) $username_id= $_COOKIE["isaac"]; else header("location:adminLogin.php");
$db = mysqli_connect('localhost', 'root', '', 'mydbase');

$errors = array();// Store and display error messages
// initializing variables
$d = "";
$h = "";
$k = "";

//Select Query to show data from database table
$sql6 = "SELECT * FROM category order by id desc";
$result6 = mysqli_query($db, $sql6);
$count6 = 0;  //Count the number of rows in that particular table
if(mysqli_num_rows($result6)>$count6){//return no of rows in present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result6))//feteches a result row as an assoc array
{
$id6[] = $row["id"];
$category6[] = $row["category"];
$count6++;
}
}

//if user clicked on the submit button receive the value from the form
if(isset($_POST['submit'])){
	$d = $_FILES['sub_image']['name'];
	$e = 'blog_pic/' .$d;
	$f = move_uploaded_file($_FILES['sub_image']['tmp_name'],$e);
	$g = mysqli_real_escape_string($db, $_POST['title']);  //mysqli() help to protect ur database fr SQL injection, and escape 
	$h = mysqli_real_escape_string($db, $_POST['story']);	//character
	$k = mysqli_real_escape_string($db, $_POST['cat_id']);
	$date = date('Y-m-d h:i:sa');
	
	if(empty($g)){ //Check whether a variable is empty or not
		array_push($errors, "Title is Required");
	}
	if(empty($h)){
		array_push($errors, "Story is Required");
	}
	if(empty($k)){
		array_push($errors, "Category is Required");
	}
	
	//Query database or execute SQL query to insert into database
	$insert = mysqli_query($db, "insert into blog(sub_image, title, story, date, cat_id)values('$d', '$g', '$h', '$date' '$k', now())") or die('could not insert' .mysqli_error($db));
	if($insert){
		array_push($errors, "Content Uploaded Successfully");
	}
	else{
		array_push($errors, "Not Uploaded");
	}
}
//Admin Blog End

//Admin Event Start
$errors = array(); // Store and display error messages

if(isset($_COOKIE["isaac"])) $username_id= $_COOKIE["isaac"]; else header("location:adminLogin.php");
$sql1 = "SELECT * FROM category order by id desc";//Select Query to show data from database table
$result = mysqli_query($db, $sql1);
$count = 0;		//Count the number of rows in that particular table
if(mysqli_num_rows($result)>$count){ //return no of rows in present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result))  //feteches a result row as an assoc array
{
$id[] = $row["id"];
$category[] = $row["category"];
$count++;
}
}

//if user clicked on the submit button receive the value from the form
if(isset($_POST['submit'])){
	$d = $_FILES['sub_image']['name'];
	$e = 'event_pic/' .$d;
	$f = move_uploaded_file($_FILES['sub_image']['tmp_name'],$e);
	$g = mysqli_real_escape_string($db, $_POST['title']);
	$h = mysqli_real_escape_string($db, $_POST['story']);
	$l = mysqli_real_escape_string($db, $_POST['event_venue']);//mysqli() help to protect ur database fr SQL injection, and escape 
	$m = mysqli_real_escape_string($db, $_POST['event_time']); //character
	$trn_date = date("Y-m-d H:i:S");
	$k = mysqli_real_escape_string($db, $_POST['cat_id']);
	
	//Query database or execute SQL query to insert into database
	$insert = mysqli_query($db, "insert into event(sub_image, title, story, event_venue, event_time, trn_date, cat_id)values('$d', '$g', '$h', '$l', '$m', '$trn_date' '$k', now())") or die('could not insert' .mysqli_error($db));
	if($insert){
		array_push($errors, "Content Uploaded Successfully");
	}
	else{
		array_push($errors, "Not Uploaded");
	}
}
//Admin Event End

//Upload Category Start
if(isset($_COOKIE["isaac"])) $username_id= $_COOKIE["isaac"]; else header("location:adminLogin.php");

$errors = array(); 
if(isset($_POST['submit-cat'])){
	$a = mysqli_real_escape_string($db, $_POST['category']);
	$trn_date = date("Y-m-d H:i:S");
	
	//Check whether a variable is empty or not
	if(empty($category)){
		array_push($errors, "Category is Required");
	}
	//Query database or execute SQL query to insert into database
	$insert = "insert into category (category, trn_date) values('$a', '$trn_date')" or die('could not inser' .mysqli_error($db));
	mysqli_query($db, $insert);
	if($insert){
		array_push($errors, "Category Uploaded Successfully");
	}
}
//Upload Category End

//Cause Edit Start
if(isset($_COOKIE['isaac'])) $username_id = $_COOKIE['isaac'];
else header("location:adminLogin.php");
	
$errors = array();// Store and display error messages

if(isset ($_GET['id']))
			{
				$onye=$_GET['id'];
				$del= "DELETE from about where id= '$onye'";//Delete a partular row from the the table
				$remove = mysqli_query ($db,$del);
				if($remove) {
					array_push($errors, "Deleted");
				} else {
					"Could not delete".mysqli_error();
				}
			}
			
//Select Query to show data from database table
$sql = "select * FROM about order by id desc";
$result = mysqli_query($db, $sql) or die("could not select Register".mysql_error());
$count=0;//Count the number of rows in that particular table
if (mysqli_num_rows($result)>$count){ //return no of rows in present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result)) { //feteches a result row as an assoc array
	$id[]= $row["id"];	
	$title[]= $row["title"];
		
		$count++;
	}
}
$sn=1;
//Cause Edit End

//Cause Edit Picture Start
//if user clicked on the submit button receive the value from the form
if(isset($_COOKIE['isaac'])) $username_id = $_COOKIE['isaac'];
else header("location:adminLogin.php");
$id = isset($_GET['id']) ? $_GET['id'] : '';

if(isset($_POST['submit'])){
	$c= $_FILES['image']['name'];
	$d= 'upload/'.$c;
	$e= move_uploaded_file($_FILES['image']['tmp_name'],$d);
	//Query database or execute SQL query to update into database
		$insert= mysqli_query($db, "update about set image ='$c' where id= '$id'") or die(mysqli_error());
		if($insert){echo 'successful';}else {'could not insert'.mysqli_error();}
	   
	}

//Cause Edit Picture End

//Cause Edit Dashboard Start
if(isset($_COOKIE['isaac'])) $username_id = $_COOKIE['isaac'];
else header("location:adminLogin.php");

$errors = array();// Store and display error messages

//$a = $_GET["id"];
$id = "";
if(isset($_POST["id"])){
$id = $_GET["id"];
 }
//Select Query to show data from database table
$sql1 = "SELECT * FROM category order by id desc";
$result1 = mysqli_query($db, $sql1);
$count1 = 0; //Count the number of rows in that particular table
if(mysqli_num_rows($result1)>$count1){//return no of rows in present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result1)) //feteches a result row as an assoc array
{

$id1[] = $row["id"];
$category1[] = $row["category"];
$count1++;
}
}

//Query database or execute SQL query to select fr database
$sql = "SELECT * FROM about where id= '$id'";
$result = mysqli_query($db, $sql);
if (mysqli_num_rows($result)){//return no of rows in present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result)) {//feteches a result row as an assoc array
	$id= $row["id"];	
	$title= $row["title"];
	$content = $row["story"];
	$raised = $row["raised"];	
	$category= $row["cat_id"];	
	}
}

//if user clicked on the submit button receive the value from the form
if(isset($_POST['submit'])){
		$a= $_POST['title'];
		$f= $_POST['story'];
		$g= $_POST['raised'];
		$h= $_POST['cat_id'];
	
	//Query database or execute SQL query to update into database
		$insert= mysqli_query($db, "update about set title ='$a', story ='$f', raised ='$g' cat_id ='$h' where id='$id'");
		if($insert)
		{
			array_push($errors, "Edit Uploaded Successful");
		}
		else 
		{
			array_push($errors, "Edit Upload Successful");
		}
	   
	}

//Cause Edit Dashboard End

//Blog Edit Start
if(isset($_COOKIE['isaac'])) $username_id = $_COOKIE['isaac'];
else header("location:adminLogin.php");
$errors = array();

if(isset ($_GET['id']))
			{
				$emeri=$_GET['id'];
				$del= "DELETE from blog where id= '$emeri'";
				$remove =mysqli_query ($db,$del); //Delete a partular row from the the table
				if($remove) {
					array_push($errors, "Deleted");
				} else {
					"Could not delete".mysqli_error();
				}
			}
			
//Select Query to show data from database table
$sql12 = "select * FROM blog order by id desc";
$result12 = mysqli_query($db, $sql12);
$count12=0;
if (mysqli_num_rows($result12)>$count12){
	while($row=mysqli_fetch_assoc($result12)) {
	$id12[]= $row["id"];	
	$title12[]= $row["title"];
		
		$count12++;
	}
}
$sn=1;
//Blog Edit End

//Blog Edit Picture Start
if(isset($_COOKIE['isaac'])) $username_id = $_COOKIE['isaac']; else header("location:adminLogin.php");
$chi = isset($_GET['id']) ? $_GET['id'] : '';

//if user clicked on the submit button receive the value from the form
if(isset($_POST['submit'])){
	$c= $_FILES['image']['name'];
	$d= 'blog_pic/'.$c;
	$e= move_uploaded_file($_FILES['image']['tmp_name'],$d);
	
		//Query database or execute SQL query to update into database
		$insert= mysqli_query($db, "update blog set image ='$c' where id='$chi'");
		if($insert){echo 'successful';}else {'could not insert'.mysqli_error($db);}
	   
	}
//Blog Edit Picture End


//Event Edit Start
if(isset ($_GET['id']))
			{
				$onye=$_GET['id'];
				$del= "DELETE from event where id= '$onye'"; //Delete a partular row from the the table
				$remove =mysqli_query ($db,$del);
				if($remove) {"echo value deleted";} else {"Could not delete".mysqli_error();}
			}
//Select Query to show data from database table
$sql = "select * FROM event order by id desc";
$result = mysqli_query($db, $sql);
$count=0;
if (mysqli_num_rows($result)>$count){
	while($row=mysqli_fetch_assoc($result)) {
	$id[]= $row["id"];	
	$title[]= $row["title"];
		
		$count++;
	}
}
$sn=1;

//Event Edit End

//Event Edit Picture Start
$onye = 'id';
if(isset($_GET['id'])){
$onye = $_GET['id'];	
}

//if user clicked on the submit button receive the value from the form
if(isset($_POST['submit'])){
	$c= $_FILES['image']['name'];
	$d= 'event_pic/'.$c;
	$e= move_uploaded_file($_FILES['image']['tmp_name'],$d);
	
		//Query database or execute SQL query to update into database
		$update = mysqli_query($db, "update event set image ='$c' WHERE id='$onye'");
		if($update){echo 'successful';}else {'could not insert'.mysqli_error($db);}
	}
//Event Edit Picture End
?>
