<?php 
require'dbconn.php';
// connect to the database
$db = mysqli_connect(servername, username, password, dbname);
//Index Start
//Select Query to show data from database table
$sql2 = "SELECT * FROM about WHERE cat_id = 2147483647 order by id desc limit  6";
$result2 = mysqli_query($db, $sql2);
$count2 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result2)>$count2){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result2)) {//feteches a result row as an assoc array
		$sub_image2[] =$row['sub_image'];
		$title2[] =$row['title'];
		$raised2[] =$row['raised'];
		$trn_date2[] =date("d-M-Y");
		$id2[]= $row["id"];
		$cat_id2[] = $row['cat_id'];
		$count2++;
		
	}
	}

//Select Query to show data from database table
$sql7 = " SELECT * FROM blog WHERE cat_id = 2147483647 order by id desc limit 3";
$result7 = mysqli_query($db, $sql7);
$count7 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result7)>$count7){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result7)) {
		$sub_image7[] = $row['sub_image'];
		$title7[] = $row['title'];
		$id7[] = $row['id'];
		$category7[] = $row['cat_id'];
		$date7 = date('Y-m-d h:i:sa');
		$count7++;
		
	}
}

//Select Query to show data from database table
$sql = " SELECT * FROM donate order by id desc limit 3"; 
$result = mysqli_query($db, $sql);
$count = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result)>$count){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result)){
		$full_name[] = $row['full_name'];
		$trn_date[] = date("Y-m-d H:i:s");
		$amount[] = $row['amount'];
		$purpose[] = $row['purpose'];
		$image[] = $row['image'];
		$count++;
		}
}

//Select Query to show data from database table
$sql13 = "SELECT * FROM event WHERE cat_id = 2147483647 order by id desc limit 3";
$result13 = mysqli_query($db, $sql13);
$count13 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result13)>$count13){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result13)) {
		$sub_image13[] =$row['sub_image'];
		$title13[] =$row['title'];
		$event_time13[] =$row['event_time'];
		$event_venue13[] =$row['event_venue'];
		$trn_date13[] =date("d-M-Y");
		$id13[]= $row["id"];
		$cat_id13[] = $row['cat_id'];
		$count13++;
		
	}
	}
//Index End


//Aabout Start
//Select Query to show data from database table
$sql = " SELECT * FROM donate order by id desc limit  3"; 
$result = mysqli_query($db, $sql);
$count = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result)>$count){
	while($row=mysqli_fetch_assoc($result)){//return no of rows present in the result set(check if data is present in database)
		$full_name[] = $row['full_name'];
		$trn_date[] = date("Y-m-d H:i:s");
		$amount[] = $row['amount'];
		$purpose[] = $row['purpose'];
		$image[] = $row['image'];
		$count++;
		}
}
//Select Query to show data from database table
$sql7 = " SELECT * FROM blog WHERE cat_id = 2147483647 order by id desc limit 3";
$result7 = mysqli_query($db, $sql7);
$count7 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result7)>$count7){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result7)) {
		$sub_image7[] = $row['sub_image'];
		$title7[] = $row['title'];
		//$story7[] = $row['story'];
		$id7[] = $row['id'];
		$category7[] = $row['cat_id'];
		$date7 = date('Y-m-d h:i:sa');
		$count7++;
		
	}
}
//About End



//Causes Start
//Select Query to show data from database table
$sql2 = "SELECT * FROM about WHERE cat_id = 2147483647 order by id desc limit  6";
$result2 = mysqli_query($db, $sql2);
$count2 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result2)>$count2){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result2)) {
		$sub_image2[] =$row['sub_image'];
		$title2[] =$row['title'];
		//$story2[] =$row['story'];
		$raised2[] =$row['raised'];
		$trn_date2[] =date("d-M-Y");
		$id2[]= $row["id"];
		$cat_id2[] = $row['cat_id'];
		$count2++;
		
	}
	}
//Select Query to show data from database table
$sql7 = " SELECT * FROM blog WHERE cat_id = 2147483647 order by id desc limit 3";
$result7 = mysqli_query($db, $sql7);
$count7 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result7)>$count7){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result7)) {
		$sub_image7[] = $row['sub_image'];
		$title7[] = $row['title'];
		//$story7[] = $row['story'];
		$id7[] = $row['id'];
		$category7[] = $row['cat_id'];
		$date7 = date('Y-m-d h:i:sa');
		$count7++;
		
	}
}
//Causes End



//Donate Start
//Select Query to show data from database table
$sql = " SELECT * FROM donate order by id desc limit  6"; 
$result = mysqli_query($db, $sql);
$count = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result)>$count){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result)){
	//while($row=mysqli_fetch_array($result8, MYSQL_ASSOC))
		$full_name[] = $row['full_name'];
		$trn_date[] = date("Y-m-d H:i:s");
		$amount[] = $row['amount'];
		$purpose[] = $row['purpose'];
		$image[] = $row['image'];
		$count++;
		}
}
//Select Query to show data from database table
$sql7 = " SELECT * FROM blog WHERE cat_id = 2147483647 order by id desc limit 3";
$result7 = mysqli_query($db, $sql7);
$count7 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result7)>$count7){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result7)) {
		$sub_image7[] = $row['sub_image'];
		$title7[] = $row['title'];
		//$story7[] = $row['story'];
		$id7[] = $row['id'];
		$category7[] = $row['cat_id'];
		$date7 = date('Y-m-d h:i:sa');
		$count7++;
		
	}
}
//Donate End

//Blog Start
//Select Query to show data from database table
$sql7 = " SELECT * FROM blog WHERE cat_id = 2147483647 order by id desc limit 6";
$result7 = mysqli_query($db, $sql7);
$count7 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result7)>$count7){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result7)) {
		$sub_image7[] = $row['sub_image'];
		$title7[] = $row['title'];
		//$story7[] = $row['story'];
		$id7[] = $row['id'];
		$category7[] = $row['cat_id'];
		$date7 = date('Y-m-d h:i:sa');
		$count7++;
		
	}
}

//Select Query to show data from database table
$sql71 = " SELECT * FROM blog WHERE cat_id = 2147483647 order by id desc limit 3";
$result71 = mysqli_query($db, $sql71);
$count71 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result71)>$count71){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result71)) {
		$sub_image71[] = $row['sub_image'];
		$title71[] = $row['title'];
		//$story7[] = $row['story'];
		$id71[] = $row['id'];
		$category71[] = $row['cat_id'];
		$date71 = date('Y-m-d h:i:sa');
		$count71++;
		
	}
}
//Blog End 



//Gallery Start
//Select Query to show data from database table
$sql7 = " SELECT * FROM blog WHERE cat_id = 2147483647 order by id desc limit 3";
$result7 = mysqli_query($db, $sql7);
$count7 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result7)>$count7){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result7)) {
		$sub_image7[] = $row['sub_image'];
		$title7[] = $row['title'];
		//$story7[] = $row['story'];
		$id7[] = $row['id'];
		$category7[] = $row['cat_id'];
		$date7 = date('Y-m-d h:i:sa');
		$count7++;
		
	}
}
//Gallery End



//Event Start
//Select Query to show data from database table
$sql13 = "SELECT * FROM event WHERE cat_id = 2147483647 order by id desc limit  6";
$result13 = mysqli_query($db, $sql13);
$count13 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result13)>$count13){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result13)) {
		$sub_image13[] =$row['sub_image'];
		$title13[] =$row['title'];
		//$story2[] =$row['story'];
		$event_time13[] =$row['event_time'];
		$event_venue13[] =$row['event_venue'];
		$trn_date13[] =date("d-M-Y");
		$id13[]= $row["id"];
		$cat_id13[] = $row['cat_id'];
		$count13++;
		
	}
	}
//Select Query to show data from database table
$sql7 = " SELECT * FROM blog WHERE cat_id = 2147483647 order by id desc limit 3";
$result7 = mysqli_query($db, $sql7);
$count7 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result7)>$count7){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result7)) {
		$sub_image7[] = $row['sub_image'];
		$title7[] = $row['title'];
		//$story7[] = $row['story'];
		$id7[] = $row['id'];
		$category7[] = $row['cat_id'];
		$date7 = date('Y-m-d h:i:sa');
		$count7++;
		
	}
}
//Event End 




//Contact Start
//Select Query to show data from database table
$sql7 = " SELECT * FROM blog WHERE cat_id = 2147483647 order by id desc limit 3";
$result7 = mysqli_query($db, $sql7);
$count7 = 0;//Count the number of rows in that particular table
if (mysqli_num_rows($result7)>$count7){//return no of rows present in the result set(check if data is present in database)
	while($row=mysqli_fetch_assoc($result7)) {
		$sub_image7[] = $row['sub_image'];
		$title7[] = $row['title'];
		//$story7[] = $row['story'];
		$id7[] = $row['id'];
		$category7[] = $row['cat_id'];
		$date7 = date('Y-m-d h:i:sa');
		$count7++;
		
	}
}
//Contact End
?>