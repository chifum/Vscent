<?php
include'config.php';
//Create connection
$db = mysqli_connect(servername, username, password);

//Check Connection
if ($db->connect_error){
	die("connection failed: " . $db->connect_error);
}
//else{
	//echo "connected successfully";

//}
?>


