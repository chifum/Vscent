<?php
include'config.php';
//create connection
$db = mysqli_connect(servername, username, password, dbname);
//Check connection
if($db->connect_error){
	echo "Connection Failed: " . $db->connect_error;
}
//Sql To Create Table
$sql = "CREATE TABLE users(
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstName VARCHAR(225) NOT NULL,
lastName VARCHAR(225) NOT NULL,
username VARCHAR(225) NOT NULL,
email VARCHAR(225) NOT NULL,
password VARCHAR(225) NOT NULL,
trn_date datetime
)";

if($db->query($sql) === TRUE){
	echo "Table Users created successfully <br>";
}
else{
	echo "Error craeting table: <br>" . $db->connect_error;
}


//Sql To Create category table
$sql2 = "CREATE TABLE category(
id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
category VARCHAR(225) NOT NULL,
trn_date datetime
)";

if($db->query($sql2) === TRUE){
	echo "Table ca created successfully <br>";
}
else{
	echo "Error craeting table: <br>" . $db->connect_error;
}


$sql3 = "CREATE TABLE about(
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
sub_image VARCHAR(225) NOT NULL,
title VARCHAR(225) NOT NULL,
story VARCHAR(999) NOT NULL,
raised VARCHAR(225) NOT NULL,
trn_date datetime,
cat_id int not null
)";

if($db->query($sql3) === TRUE){
	echo "Table about created successfully <br>";
}
else{
	echo "Error creating table: <br>" . $db->connect_error;
}

$sql4 = "CREATE TABLE volunteer(
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
your_name VARCHAR(255) NOT NULL,
your_email VARCHAR(255) NOT NULL,
message VARCHAR(500) NOT NULL,
trn_date datetime
)";
if($db->query($sql4) === TRUE ){
	echo "Table Created Successfully <br>";
}
else{
	echo "Error Creating Table: <br>" .$db->connect_error;
}

$sql4 = "CREATE TABLE donate(
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
full_name VARCHAR(50) NOT NULL,
email VARCHAR(40) NOT NULL,
amount VARCHAR(40) NOT NULL,
purpose VARCHAR(40) NOT NULL,
image VARCHAR(40) NOT NULL,
trn_date datetime
)";
if($db->query($sql4) === TRUE){
	echo "Donation Table Created Successfully <br>";
}
else{
	echo "Error Creating Table: <br>" .$db->connect_error;
}

$sql3 = "CREATE TABLE blog(
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
sub_image VARCHAR(225) NOT NULL,
title VARCHAR(225) NOT NULL,
story VARCHAR(999) NOT NULL,
cat_id int not null,
date datetime)";

if($db->query($sql3) === TRUE){
	echo "Table about created successfully <br>";
}
else{
	echo "Error creating table: <br>" . $db->connect_error;
}

$sql5 = " CREATE TABLE event(
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
sub_image VARCHAR(225) NOT NULL,
title VARCHAR(225) NOT NULL,
story VARCHAR(999) NOT NULL,
event_venue VARCHAR(255) NOT NULL,
event_time VARCHAR(100) NOT NULL,
trn_date datetime,
cat_id int not null
)";
if($db->query($sql5) === TRUE){
	echo "Table Gallery Created </br>";
}
else{
	echo "Error Creating Table " . $db->connect_error;
}
$db->close();
?>