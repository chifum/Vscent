<?php
// Create connection
$db = mysqli_connect(servername, username, password);
// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
if (count($errors) > 0) : ?>
  <div class="error" style="color: #5B6FE3">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
<?php  endif
?>