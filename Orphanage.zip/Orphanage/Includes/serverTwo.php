<?php
//Connect to database
$errors = [];
$email = "";
$db = new mysqli('localhost', 'root', '', 'mydbase');
/*
  Accept email of user whose password is to be reset
  Send email to user to reset their password
*/
if(isset($_POST['reset-password'])){
	$email = mysqli_real_escape_string($_POST['email']);
	//$trn_date = date("Y-m-d H:s:1");

//// ensure that the user exists on our system and email Validation
$query = "SELECT * FROM users WHERE email ='$email'";
$results = mysqli_query($db, $query);

if (empty($email)) {
    array_push($errors, "Your email is required");
}
else if(mysqli_num_rows($results) <= 0) {
    array_push($errors, "Sorry, no user exists on our system with that email");
  }
 // generate a unique random token of length 100
  $token = bin2hex(random_bytes(50));

  if (count($errors) == 0) {
    // store token in the password-reset database table against the user's email
    $sql = "INSERT INTO password_reset(email, trn_date token) VALUES ('$email', '$trn_date', '$token')";
    $results = mysqli_query($db, $sql);
	  
	 // Send email to user with the token in a link they can click on
    $to = $email;
    $subject = "Reset your password on examplesite.com";
    $msg = "Hi there, click on this <a href=\"new_password.php?token=" . $token . "\">link</a> to reset your password on our site";
    $msg = wordwrap($msg,70);
    $headers = "From: info@examplesite.com";
    mail($to, $subject, $msg, $headers);
    header('location: pending.php?email=' . $email);
  }
}


//Enter New Password
if(isset($_POST['new-password'])){
	$password = mysqli_real_escape_string($_POST['password']);
	$cpassword = mysqli_real_escape_string($_POST['cpassword']);
	
	 // Grab to token that came from the email link
  $token = $_SESSION['token'];
  if (empty($new_pass) || empty($new_pass_c)) 
	  array_push($errors, "Password is required");
  if ($new_pass !== $new_pass_c) 
	  array_push($errors, "Password do not match");
	
	// select email address of user from the password_reset table
	$sql = "SELECT * FROM password_reset WHERE token = '$token' LIMIT 1";
	$results = mysqli_query($db, $sql);
	$email = mysqli_fetch_assoc($results)['email'];
	
	
	if ($email) {
		$new_pass = md5($new_pass);
		$sql = "UPDATE users SET password='$new_pass' WHERE email='$email'";
		$results = mysqli_query($db, $sql);
		header("location:adminIndex.php");
	}
}
?>