<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../../maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="../../ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="../../cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="../../maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<style>
		.wrapper{
			width: 100%;
			height: 100px;
			margin-top: 30px;
			background-color: darkblue;
		}
		h1{
			width: 92%;
			height: 100px;
  			margin: 0px auto; 
  			padding: 10px; 
  			border: 1px solid #a94442; 
  			color: #a94442; 
  			background: #f2dede; 
  			border-radius: 5px; 
  			text-align: center;
			
		}
	</style>
</head>
<body>

<div class="wrapper">
	<div class="container-fluid">
  		<div class="row">
    		<div class="col-sm-12" style="background-color:red;">
				<h1>You are registered successfully.</h1>
			</div>
  		</div>
	</div>
</div>
</body>
</html>
