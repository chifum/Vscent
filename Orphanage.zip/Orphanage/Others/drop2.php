<?php
session_start();
// initializing variables
$userName = "";
$email    = "";
$errors = array();


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDBase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



// REGISTER USER
if (isset($_POST['submit'])) {
  // receive all input values from the form
  $firstName = mysqli_real_escape_string($conn, $_POST['firstName']);	
  $lastName = mysqli_real_escape_string($conn, $_POST['lastName']);
  $userName = mysqli_real_escape_string($conn, $_POST['userName']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);
  $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($firstName)) { array_push($errors, "Firstname is required"); }
  if (empty($lastName)) { array_push($errors, "Lastname is required"); }
  if (empty($userName)) { array_push($errors, "Username is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password)) { array_push($errors, "Password is required"); }
  if ($password != $cpassword) {
	array_push($errors, "The two passwords do not match");
  }

	
	 // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $sql_userName = "Select FROM MYadmin WHERE userName = '$userName'";
  $sql_email	= "Select FROM MYadmin WHERE email	  =	 '$email'";
  
  $result_userName = mysqli_query($conn, $sql_userName) or die(mysqli_query($conn));
  $result_email	   = mysqli_query($conn, $sql_email)	or die(mysqli_query($conn));
	
	if (mysqli_num_rows($result_userName)>0){
		$errors = "Sorry...Username already taken";
	}
	else if(mysqli_num_rows($email)>0){
		$errors = "Sorry...Email already taken";
	}
  
	
if (count($errors) == 0) {
  	$password = md5($cpassword);//encrypt the password before saving in the database

  	$sql = mysqli_query($conn, "insert into MYadmin(firstName, lastName, userName, email, password, cpassword)values('$firstName', '$lastName', '$userName', '$email', '$password', '$password')") or die ('could not insert'.mysqli_error($conn));
  	mysqli_query($conn, $sql);
  	$_SESSION['userName'] = $userName;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: adminIndex.php');
  }
	
	
	
	

	
	
}


$conn->close();
?>





<?php
$servername = "localhost";
$username	= "root";
$password	= "";
$dbname		= "myDBase";

//Check Connection
$conn = new mysqli($servername, $username, $password, $dbname);
if($conn->connect_error){
	die("Connection Failed: " . $conn->connect_error);
}
//Receive All data in the form and submit to database
if(isset($_POST['submit'])){
	$firstName = $_POST['firstName'];
	$lastName  = $_POST['lastName'];
	$userName  = $_POST['userName'];
	$email	   = $_POST['email'];
	$password  = $_POST['password'];
	$cpassword = $_POST['cpassword'];
	
	

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SB Admin - Register</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body class="bg-dark">

  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Register an Account</div>
      <div class="card-body">
        <form action="adminRegister.php" method="post" enctype="multipart/form-data">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <div class="form-label-group">
                  <input type="text" name="firstName" id="firstName" class="form-control" placeholder="First name" required="required" autofocus="autofocus" value="<?php if(isset($firstName)) {echo $firstName;} ?>">
                  <label for="firstName">First name</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-label-group">
                  <input type="text" name="lastName" id="lastName" class="form-control" placeholder="Last name" required="required" value="<?php if(isset($lastname)) {echo $lastname;} ?>">
                  <label for="lastName">Last name</label>
                </div>
              </div>		
            </div>
          </div>
		  <div class="form-group">
            <div class="form-label-group">
              <input type="text" name="userName" id="userName" class="form-control" placeholder="Username" required="required" value="<?php if(isset($userName)) {echo $userName;} ?>">
              <label for="userName">Username </label>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
              <input type="email" name="email" id="email" class="form-control" placeholder="Email address" required="required" value="<?php if(isset($email)) {echo $email;} ?>">
              <label for="inputEmail">Email address</label>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <div class="form-label-group">
                  <input type="password" name="password" id="password" class="form-control" placeholder="Password" required="required" value="<?php if(isset($password)) {echo $password;} ?>">
                  <label for="inputPassword">Password</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-label-group">
                  <input type="password" name="cpassword" id="cpassword" class="form-control" placeholder="Confirm password" required="required" value="<?php if(isset($cpassword)) {echo $cpassword;} ?>">
                  <label for="cpassword">Confirm password</label>
                </div>
              </div>
            </div>
          </div>
          <a class="btn btn-primary btn-block" ><button type="submit" name="submit" id="submit" value="submit">Register</button></a>
        </form>
        <div class="text-center">
          <!--<a class="d-block small mt-3" href="adminLogin.php">Login Page</a>-->
          <a class="d-block small" href="adminForgot-password.php">Forgot Password?</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

</body>

</html>
<?php
$servername = "localhost";
$username	= "root";
$password	= "";
$dbname		= "myDBase";

//Check Connection
$conn = new mysqli($servername, $username, $password, $dbname);
if($conn->connect_error){
	die("Connection Failed: " . $conn->connect_error);
}
//Receive All data in the form and submit to database
if(isset($_POST['submit'])){
	$firstName = $_POST['firstName'];
	$lastName  = $_POST['lastName'];
	$email	   = $_POST['email'];
	$password  = $_POST['password'];
	$cpassword = $_POST['cpassword'];
	
	$pass1= password_hash($password, PASSWORD_DEFAULT);
		
		
			if($password==$cpassword){
				
			$sql = mysqli_query($conn, "insert into MYadmin(firstName, lastName, email, password, cpassword)values('$firstName', '$lastName', '$email', '$pass1', '$pass1')") or die('could not insert'. mysqli_error($conn));
			}
			else
				{
					echo "passwords do not match";
				}

$conn->close();
?>
