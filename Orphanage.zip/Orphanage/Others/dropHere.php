<?php
if(isset($_POST['submit'])){
	$a = $_POST['firstName'];
	$b = $_POST['lastName'];
	$c = $_POST['email'];
	$d = $_POST['password'];
	$e = $_POST['confirmPassword'];
	$f = $_POST['date'];
	
	$pass1 = password_hash($d, PASSWORD_DEFAULT);
	
	if($d == $e){
		$insert = mysqli_query($conn, "insert into MYadmin(firstName, lastName, email, password, confirmPassword, date)values('$a', '$b', '$c', '$pass', '$pass1', '$f')") or die('could not insert'.mysqli_error($conn));
	}
	else{
		echo 'password do not match';
	}
}


$userName_check_query = "SELECT * FROM MYadmin WHERE userName='$userName' OR email='$email' LIMIT 1";
  $result = mysqli_query($conn, $userName_check_query);
  $userName = mysqli_fetch_assoc($result);
  
  if ($userName) { // if user exists
    if ($userName['userName'] === $userName) {
      array_push($errors, "Username already exists");
    }

    if ($email['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }












$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



if(isset($_POST['submit'])){
	$a = $_POST['firstName'];
	$b = $_POST['lastName'];
	$c = $_POST['email'];
	$d = $_POST['password'];
	$e = $_POST['confirmPassword'];
	$f = $_POST['date'];
	
	$pass1 = password_hash($d, PASSWORD_DEFAULT);
	
	if($d == $e){
		$sql = "INSERT INTO MYadmin (firstName, lastName, email, password, confirmPassword, date)
				VALUES ('$a', '$b', '$c', '$pass', '$pass1', '$f')";
	}
	else{
		echo 'password do not match';
	}
}




if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} 
else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>