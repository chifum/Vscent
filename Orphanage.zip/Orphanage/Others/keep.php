<?php
// REGISTER USER
if(isset($_POST['submit'])){
  // receive all input values from the form
  $a = mysqli_real_escape_string($conn, $_POST['firstName']);
  $b = mysqli_real_escape_string($conn, $_POST['lastName']);
  $c = mysqli_real_escape_string($conn, $_POST['mail']);
  $d = mysqli_real_escape_string($conn, $_POST['password']);
  $e = mysqli_real_escape_string($conn, $_POST['c_password']);
  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($a)) { array_push($errors, "FirstName is required"); }
  if (empty($b)) { array_push($errors, "lastName is required"); }
  if (empty($c)) { array_push($errors, "Email is required"); }
  if (empty($d)) { array_push($errors, "Password is required"); }
  if ($d != $e) {
	array_push($errors, "The two passwords do not match");
}
	
   // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $c_check_query = "SELECT * FROM MYadmin WHERE mail='$c' LIMIT 1";
  $result = mysqli_query($conn, $c_check_query);
  $c = mysqli_fetch_assoc($result);
	
  // if user exists
    if ($c) { // if user exists
    //if ($c['mail'] === $c) {
      //array_push($errors, "Username already exists");
   // }

    if ($c['mail'] === $email) {
      array_push($errors, "email already exists");
    }
  }
	
    // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	$d = md5($e);//encrypt the password before saving in the database

  	$sql = mysqli_query($conn, "insert into MYadmin(firstname, lastname, mail, password, c_password)values('$a', '$b', '$c', '$d', '$d')") or die ('could not insert'.mysqli_error($conn));
  	mysqli_query($conn, $sql);
  	$_SESSION['mail'] = $c;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: index.php');
  }
}

?>

<?php
$emailErr = $userErr = $passwordErr = $cpasswordErr = $firstErr = $lastErr = "";
$email = $username = $password = $cpassword = $firstname = $lastname = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	//firstName
	if(empty($_POST['firstName'])){
		$firstErr = "Firstname is required"; 
	}
	else{
		$firstName = test_input($_POST['firstName']);
		//Check if the name contain only letter or whitespace
		if (!preg_match("/^[a-zA-Z ]*$/",$firstName)) {
      $firstErr = "Only letters and white space allowed";
    }
	}
	//lastName
	if(empty($_POST['lastName'])){
		$lastErr = "LastName is required";
	}
	else{
		$lastName = test_input($_POST['firstName']);
		//Check if the name contain only letter or whitespace
		if (preg_match("/^[a-zA ]*$/",$lastName)){
			$lastName = "Only letters and white space allowed";
		}
	}
	//Username
	if(empty($_POST['userName'])){
		$userErr = "Username is required";
	}
	else{
		$username = test_input($_POST['userName']);
	}
	//Email
	if(empty($_POST['email'])){
		$emailErr = "Email is required";
	}
	else{
		$email = test_input($_POST['email']);
		//check if the email is well-formed
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$emailErr = "Invalid email format";
		}
	}
	//Validates password & confirm passwords.
    if(!empty($_POST["password"]) && ($_POST["password"] == $_POST["cpassword"])) {
    $password = test_input($_POST["password"]);
    $cpassword = test_input($_POST["cpassword"]);
    if (strlen($_POST["password"]) <= 8) {
        $passwordErr = "Your Password Must Contain At Least 8 Characters!";
    }
    elseif(!preg_match("#[0-9]+#",$password)) {
        $passwordErr = "Your Password Must Contain At Least 1 Number!";
    }
    elseif(!preg_match("#[A-Z]+#",$password)) {
        $passwordErr = "Your Password Must Contain At Least 1 Capital Letter!";
    }
    elseif(!preg_match("#[a-z]+#",$password)) {
        $passwordErr = "Your Password Must Contain At Least 1 Lowercase Letter!";
    } else {
        $cpasswordErr = "Please Check You've Entered Or Confirmed Your Password!";
    }
	}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	
	<div class="col-md-6">
                <div class="form-label-group">
                  <input type="text" name="userName" id="userName" class="form-control" placeholder="User Name" required="required" autofocus="autofocus" value="<?php if(isset($userName)) {echo $userName;} ?>">
                  <label for="userName">Username</label>
                </div>
              </div>
</body>
</html>



<?php
//$email = "";
//$cpassword = "";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDBase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	
}

//REGISTER USER
if(isset($_POST['submit']))
{
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$cpassword = $_POST['cpassword'];
	
	//Re-type Password
	$sql_cpassword = "select * FROM MYadmin WHERE password = '$cpassword'";
	$result_cpassword = mysqli_query($conn, $sql_cpassword) or die(mysqli_query($conn));
	if	(mysqli_num_rows($result_cpassword)>0){
		$cpassword_error = "Password do not match";
	}
	
	//Email taklen
	$sql_email = "select * FROM MYadmin WHERE email = '$email' LIMIT 1";
	$result_email = mysqli_query($conn, $sql_email) or die(mysqli_query($conn));
	if (mysqli_num_rows($result_email)>0){
		$email_error = "Email Already Taken";
	}
	
	//Password Hash
	
	$pass1= password_hash($password, PASSWORD_DEFAULT);
	if($password==$cpassword){
				
			$sql = mysqli_query($conn, "insert into MYadmin(firstName, lastName, email, password, cpassword)values('$firstName', '$lastName', '$email', '$pass1', '$pass1')") or die('could not insert'. mysqli_error($conn));
		
			$cpassword_error = "Password do not match";
			//setcookie("emeri", $chifum, time()+3600);
			//header("location:adminIndex.php");
			}
			


}
$conn->close();
?>