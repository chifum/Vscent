<?php


//$servername = "localhost";
//$username	= "root";
//$password	= "";
//$dbname		= "myDBase";

//Create Connection
//$conn = new mysqli($servername, $username, $password, $dbname);
//Check connection
//if($conn->connect_error){
	//die("Connection Failed: " . $conn->connect_error);
//}

//USER REGISTER
if(isset($_POST['submit'])){
	$firstName = mysqli_real_escape_string($conn, $_POST['firstName']);
	$lastName	= mysqli_real_escape_string($conn, $_POST['lastName']);
	$username		= mysqli_real_escape_string($conn, $_POST['user_Name']);
	$email		= mysqli_real_escape_string($conn, $_POST['email']);
	$password	= mysqli_real_escape_string($conn, $_POST['password']);
	$cpassword	= mysqli_real_escape_string($conn, $_POST['cpassword']);
	//$trn_date = date("Y-m-d H:i:s");
	
	//Form Validation
	if(empty($firstName)){
		array_push($errors, "Firstname is Required");
	}
	
	if(empty($lastName)){
		array_push($errors, "Lastname is Required");
	}
	
	if(empty($user_Name)){
		array_push($errors, "Username is Required");
	}
	
	//if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		//array_push($errors = "Invalid Email");
	//}
	if(empty($email)){
		array_push($errors, "Email is Required");
	}
	
	if(empty($password)){
		array_push($errors, "Password is Required");
	}
	
	//Password hash
	if($password != $cpassword){
		array_push($errors, "Password do not match");
	}
	
	//Check if user or email already exist in database
	$user_check_query = "SELECT * FROM users WHERE user_Name='$user_Name' OR email='$email' LIMIT 1";
  $result = mysqli_query($conn, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['user_Name'] === $user_Name) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }
	
	//register user if no errors in the form
	if(count($errors) == 0){
		$pass1 = md5($password);
		
		$sql = "insert into MYadmin(firstName, lastName, user_Name, email, password, cpassword)values('$firstName', '$lastName', '$user_Name' '$email', '$pass1', '$pass1')" or die ('could not insert'.mysqli_error($conn));
		mysqli_query($conn, $sql);
		//$_SESSION['email'] = $email;
		//$_SESSION['success'] = "You are now logged in";
		//header('location:adminIndex.php');
	}
	
}






?>