
<?php
$user_check_query = "SELECT * FROM users WHERE user_Name='$user_Name' OR email='$email' LIMIT 1";
  $result_1 = mysqli_query($conn, $user_check_query);
  $user = mysqli_fetch_assoc($result_1);
  
  if ($user) { // if user exists
    if ($user['user_Name'] === $user_Name) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }





<?php include('errors.php'); ?>
  ?>