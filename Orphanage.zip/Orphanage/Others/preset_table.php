<?php
$servername = "localhost";
$username	= "root";
$password	= "";
$dbname		= "mydbase";
//create connection
$db = new mysqli($servername, $username, $password, $dbname);
//Check connection
if($db->connect_error){
	echo "Connection Failed: " . $db->connect_error;
}
//Sql To Create Table
$sql = "CREATE TABLE passwordReset(
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
email VARCHAR(225) NOT NULL,
token VARCHAR(225) NOT NULL UNIQUE,
trn_date datetime
)";

if($db->query($sql) === TRUE){
	echo "Table passwordReset created successfully";
}
else{
	echo "Error craeting table: " . $db->connect_error;
}
$db->close();
?>